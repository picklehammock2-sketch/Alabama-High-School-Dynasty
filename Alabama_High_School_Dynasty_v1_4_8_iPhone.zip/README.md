Alabama High School Dynasty v1.4.7 — iPhone Edition

Patch:
- Grayson Marlowe is a recurring fictional archrival head coach Easter egg and can create persistent rivalry/bad-blood flavor.
- Joey Etheredge is a recurring fictional chaos coach who can trigger humorous program trouble or dismissal stories.
- Existing dynasty, scheduling, showcase, transfer, eligibility, stats, and iPhone/browser systems are preserved from the prior build.


v1.4.8 launch fix: invokes home() after the complete engine is defined; updates visible version labels.
